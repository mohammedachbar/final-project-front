export default function Hello() {
    return (
        <h1>This is an h1 heading</h1>
    )
  }
  