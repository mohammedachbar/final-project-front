function FruitsCounter(props) {
    return (
        <h2>Total fruits: {props.fruitsList.length}</h2>
    )
}

export default FruitsCounter;